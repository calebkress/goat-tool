#ifndef UTILITY_FUNCTIONS_H
#define UTILITY_FUNCTIONS_H
#include <stdio.h>

// Function prototypes
void print_content(const char* file_path);
void display_help_page();

#endif
