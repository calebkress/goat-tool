# goat-tool
A basic GCC command line tool.
